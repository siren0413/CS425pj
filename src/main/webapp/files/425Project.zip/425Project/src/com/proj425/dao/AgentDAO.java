package com.proj425.dao;

import java.util.List;

import com.proj425.domain.Agent;

public interface AgentDAO {
	
	
	List<Agent> queryAllAgents();

    Agent queryAgentById(String agent_id);
    
    List<Agent> queryAgentByCondition(Agent agent);
    
    void addAgent(Agent agent);

    void deleteAgent(String agent_id);
    
    void deleteAgentSet(String agent_id_set);

    void updateAgent(Agent agent);
	
	
}
