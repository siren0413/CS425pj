package com.proj425.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.proj425.dao.BookingDAO;
import com.proj425.domain.Agent;
import com.proj425.domain.Booking;
import com.proj425.domain.Client;
import com.proj425.domain.Resort;
import com.proj425.utils.JDBC_Conn;

public class BookingDAO_Impl implements BookingDAO {

	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;

	public List<Booking> queryAllBookings() {

		List<Booking> booking_list = null;

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "select b.*, "
					+ "c.phone_number c_phone_number, c.email c_email, c.first_nm c_first_nm, c.last_nm c_last_nm, c.dob c_dob, c.zip c_zip, c.gender c_gender, "
					+ "a.phone_number a_phone_number, a.email a_email, a.first_nm a_first_nm, a.last_nm a_last_nm, a.dob a_dob, a.zip a_zip, a.gender a_gender, "
					+ "r.resort_id resort_id, r.phone_number r_phone_number, r.city_id city_id, r.resort_nm resort_nm, r.rating rating, r.address address "
					+ "from bookings b, clients c, agents a, resorts r where b.client_id = c.client_id  and b.agent_id = a.agent_id and b.resort_id = r.resort_id";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				if (booking_list == null)
					booking_list = new ArrayList<Booking>();

				Booking booking = new Booking();

				booking.setBooking_id(rs.getString("booking_id"));

				// set client
				Client client = new Client();

				client.setClient_id(rs.getString("client_id"));
				client.setPhone_number(rs.getString("c_phone_number"));
				client.setEmail(rs.getString("c_email"));
				client.setFirst_nm(rs.getString("c_first_nm"));
				client.setLast_nm(rs.getString("c_last_nm"));

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date dob = sdf.parse(rs.getString("c_dob"));

				client.setDob(dob);
				client.setZip(rs.getString("c_zip"));
				client.setGender(rs.getString("c_gender"));

				booking.setClient(client);

				// set agent

				Agent agent = new Agent();
				agent.setAgent_id(rs.getString("agent_id"));
				agent.setPhone_number(rs.getString("a_phone_number"));
				agent.setEmail(rs.getString("a_email"));
				agent.setFirst_nm(rs.getString("a_first_nm"));
				agent.setLast_nm(rs.getString("a_last_nm"));

				sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				dob = sdf.parse(rs.getString("a_dob"));

				agent.setDob(dob);
				agent.setZip(rs.getString("a_zip"));
				agent.setGender(rs.getString("a_gender"));

				booking.setAgent(agent);

				// set resort

				Resort resort = new Resort();

				resort.setResort_id(rs.getString("resort_id"));
				resort.setPhone_number(rs.getString("r_phone_number"));
				resort.setCity_id(rs.getString("city_id"));
				resort.setResort_nm(rs.getString("resort_nm"));
				resort.setRating(rs.getString("rating"));
				resort.setAddress(rs.getString("address"));

				booking.setResort(resort);

				sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date date = sdf.parse(rs.getString("book_date"));

				booking.setBook_date(date);

				date = sdf.parse(rs.getString("arrive_date"));

				booking.setArrive_date(date);

				date = sdf.parse(rs.getString("departure_date"));

				booking.setDeparture_date(date);

				booking.setRoom_type(rs.getString("room_type"));
				booking.setActivity(rs.getString("activity"));

				booking_list.add(booking);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

		return booking_list;
	}

	public Booking queryBookingById(String booking_id) {

		Booking booking = null;

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "select b.*, "
					+ "c.phone_number c_phone_number, c.email c_email, c.first_nm c_first_nm, c.last_nm c_last_nm, c.dob c_dob, c.zip c_zip, c.gender c_gender, "
					+ "a.phone_number a_phone_number, a.email a_email, a.first_nm a_first_nm, a.last_nm a_last_nm, a.dob a_dob, a.zip a_zip, a.gender a_gender, "
					+ "r.resort_id resort_id, r.phone_number r_phone_number, r.city_id city_id, r.resort_nm resort_nm, r.rating rating, r.address address "
					+ "from bookings b, clients c, agents a, resorts r where b.client_id = c.client_id  and b.agent_id = a.agent_id and b.resort_id = r.resort_id "
					+ " and  booking_id=?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, booking_id);
			rs = stmt.executeQuery();
			while (rs.next()) {

				booking = new Booking();

				booking.setBooking_id(rs.getString("booking_id"));

				// set client
				Client client = new Client();

				client.setClient_id(rs.getString("client_id"));
				client.setPhone_number(rs.getString("c_phone_number"));
				client.setEmail(rs.getString("c_email"));
				client.setFirst_nm(rs.getString("c_first_nm"));
				client.setLast_nm(rs.getString("c_last_nm"));

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date dob = sdf.parse(rs.getString("c_dob"));

				client.setDob(dob);
				client.setZip(rs.getString("c_zip"));
				client.setGender(rs.getString("c_gender"));

				booking.setClient(client);

				// set agent

				Agent agent = new Agent();
				agent.setAgent_id(rs.getString("agent_id"));
				agent.setPhone_number(rs.getString("a_phone_number"));
				agent.setEmail(rs.getString("a_email"));
				agent.setFirst_nm(rs.getString("a_first_nm"));
				agent.setLast_nm(rs.getString("a_last_nm"));

				sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				dob = sdf.parse(rs.getString("a_dob"));

				agent.setDob(dob);
				agent.setZip(rs.getString("a_zip"));
				agent.setGender(rs.getString("a_gender"));

				booking.setAgent(agent);

				// set resort

				Resort resort = new Resort();

				resort.setResort_id(rs.getString("resort_id"));
				resort.setPhone_number(rs.getString("r_phone_number"));
				resort.setCity_id(rs.getString("city_id"));
				resort.setResort_nm(rs.getString("resort_nm"));
				resort.setRating(rs.getString("rating"));
				resort.setAddress(rs.getString("address"));

				booking.setResort(resort);

				sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date date = sdf.parse(rs.getString("book_date"));

				booking.setBook_date(date);

				date = sdf.parse(rs.getString("arrive_date"));

				booking.setArrive_date(date);

				date = sdf.parse(rs.getString("departure_date"));

				booking.setDeparture_date(date);

				booking.setRoom_type(rs.getString("room_type"));
				booking.setActivity(rs.getString("activity"));

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

		return booking;
	}

	public List<Booking> queryBookingByCondition(Booking booking) {

		List<Booking> booking_list = null;
		int count = 0;

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "select b.*, "
					+ "c.phone_number c_phone_number, c.email c_email, c.first_nm c_first_nm, c.last_nm c_last_nm, c.dob c_dob, c.zip c_zip, c.gender c_gender, "
					+ "a.phone_number a_phone_number, a.email a_email, a.first_nm a_first_nm, a.last_nm a_last_nm, a.dob a_dob, a.zip a_zip, a.gender a_gender, "
					+ "r.resort_id resort_id, r.phone_number r_phone_number, r.city_id city_id, r.resort_nm resort_nm, r.rating rating ,r.address address "
					+ "from bookings b, clients c, agents a, resorts r where b.client_id = c.client_id  and b.agent_id = a.agent_id and b.resort_id = r.resort_id"
					+ " and ";

			// set client
			if (booking.getClient().getFirst_nm() != null && !"".equals(booking.getClient().getFirst_nm())) {
				sql += " c.first_nm='" + booking.getClient().getFirst_nm() + "'" + " and ";
				count++;
			}

			if (booking.getClient().getLast_nm() != null && !"".equals(booking.getClient().getLast_nm())) {
				sql += " c.last_nm='" + booking.getClient().getLast_nm() + "'" + " and ";
				count++;
			}

			// + id

			// set agent

			if (booking.getAgent().getFirst_nm() != null && !"".equals(booking.getAgent().getFirst_nm())) {
				sql += " a.first_nm='" + booking.getAgent().getFirst_nm() + "'" + " and ";
				count++;
			}

			if (booking.getAgent().getLast_nm() != null && !"".equals(booking.getAgent().getLast_nm())) {
				sql += " a.last_nm='" + booking.getAgent().getLast_nm() + "'" + " and ";
				count++;
			}

			// set booking date
			if (booking.getBook_date() != null) {

				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				String date_str = sdf.format(booking.getBook_date());
				sql += " b.book_date= " + "to_date('" + date_str + "'," + "'MM/dd/yyyy')" + " and ";
				count++;
			}

			// set arrive date
			if (booking.getArrive_date() != null) {

				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				String date_str = sdf.format(booking.getArrive_date());
				sql += " b.arrive_date= " + "to_date('" + date_str + "'," + "'MM/dd/yyyy')" + " and ";
				count++;
			}

			// set departure date
			if (booking.getDeparture_date() != null) {

				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
				String date_str = sdf.format(booking.getDeparture_date());
				sql += " b.departure_date= " + "to_date('" + date_str + "'," + "'MM/dd/yyyy')" + " and ";
				count++;
			}

			// set resort name
			if (booking.getResort().getResort_nm() != null && !"".equals(booking.getResort().getResort_nm())) {
				sql += " r.resort_nm='" + booking.getResort().getResort_nm() + "'" + " and ";
				count++;
			}

			// set room type
			if (booking.getRoom_type() != null && !"".equals(booking.getRoom_type())) {
				sql += " b.room_type='" + booking.getRoom_type() + "'" + " and ";
				count++;
			}

			// activity
			if (booking.getActivity() != null && !"".equals(booking.getActivity())) {
				sql += " b.activity='" + booking.getActivity() + "'" + " and ";
				count++;
			}

			if (count == 0)
				return queryAllBookings();

			int last_index = sql.lastIndexOf("and");
			sql = sql.substring(0, last_index);

			stmt = conn.prepareStatement(sql);

			rs = stmt.executeQuery();
			while (rs.next()) {
				if (booking_list == null)
					booking_list = new ArrayList<Booking>();

				booking = new Booking();

				booking.setBooking_id(rs.getString("booking_id"));

				// set client
				Client client = new Client();

				client.setClient_id(rs.getString("client_id"));
				client.setPhone_number(rs.getString("c_phone_number"));
				client.setEmail(rs.getString("c_email"));
				client.setFirst_nm(rs.getString("c_first_nm"));
				client.setLast_nm(rs.getString("c_last_nm"));

				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date dob = sdf.parse(rs.getString("c_dob"));

				client.setDob(dob);
				client.setZip(rs.getString("c_zip"));
				client.setGender(rs.getString("c_gender"));

				booking.setClient(client);

				// set agent

				Agent agent = new Agent();
				agent.setAgent_id(rs.getString("agent_id"));
				agent.setPhone_number(rs.getString("a_phone_number"));
				agent.setEmail(rs.getString("a_email"));
				agent.setFirst_nm(rs.getString("a_first_nm"));
				agent.setLast_nm(rs.getString("a_last_nm"));

				sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				dob = sdf.parse(rs.getString("a_dob"));

				agent.setDob(dob);
				agent.setZip(rs.getString("a_zip"));
				agent.setGender(rs.getString("a_gender"));

				booking.setAgent(agent);

				// set resort

				Resort resort = new Resort();

				resort.setResort_id(rs.getString("resort_id"));
				resort.setPhone_number(rs.getString("r_phone_number"));
				resort.setCity_id(rs.getString("city_id"));
				resort.setResort_nm(rs.getString("resort_nm"));
				resort.setRating(rs.getString("rating"));
				resort.setAddress(rs.getString("address"));

				booking.setResort(resort);

				sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
				Date date = sdf.parse(rs.getString("book_date"));

				booking.setBook_date(date);

				date = sdf.parse(rs.getString("arrive_date"));

				booking.setArrive_date(date);

				date = sdf.parse(rs.getString("departure_date"));

				booking.setDeparture_date(date);

				booking.setRoom_type(rs.getString("room_type"));
				booking.setActivity(rs.getString("activity"));

				booking_list.add(booking);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

		return booking_list;

	}

	public void addBooking(Booking booking) {

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "insert into bookings values(?,?,?,?,?,?,?,?,?)";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, booking.getBooking_id());
			stmt.setString(2, booking.getClient().getClient_id());
			stmt.setString(3, booking.getResort().getResort_id());
			stmt.setDate(4, new java.sql.Date(booking.getBook_date().getTime()));
			stmt.setDate(5, new java.sql.Date(booking.getArrive_date().getTime()));
			stmt.setDate(6, new java.sql.Date(booking.getDeparture_date().getTime()));
			stmt.setString(7, booking.getRoom_type());
			stmt.setString(8, booking.getAgent().getAgent_id());
			stmt.setString(9, booking.getActivity());

			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

	}

	public void deleteBooking(String booking_id) {
		try {
			conn = JDBC_Conn.getConnection();
			String sql = "delete from bookings where booking_id = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, booking_id);
			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

	}

	public void deleteBookingSet(String booking_id_set) {
		
		try {
			conn = JDBC_Conn.getConnection();
			String sql = "delete from bookings where booking_id in (" + booking_id_set + ")";
			stmt = conn.prepareStatement(sql);
			
			stmt.executeUpdate();
			

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

	}
	public void updateBooking(Booking booking) {
		try {
			conn = JDBC_Conn.getConnection();
			String sql = "update bookings set book_date=?, arrive_date=?, departure_date=?, activity=?, room_type=? ,client_id=? ,resort_id=?, agent_id=? where booking_id=?";
			stmt = conn.prepareStatement(sql);
			stmt.setDate(1, new java.sql.Date(booking.getBook_date().getTime()));
			stmt.setDate(2, new java.sql.Date(booking.getArrive_date().getTime()));
			stmt.setDate(3, new java.sql.Date(booking.getDeparture_date().getTime()));
			stmt.setString(4, booking.getActivity());
			stmt.setString(5, booking.getRoom_type());
			stmt.setString(6, booking.getClient().getClient_id());
			stmt.setString(7, booking.getResort().getResort_id());
			stmt.setString(8, booking.getAgent().getAgent_id());
			stmt.setString(9, booking.getBooking_id());
			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

	}

}
