package com.proj425.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.proj425.dao.ResortDAO;
import com.proj425.domain.Resort;
import com.proj425.utils.JDBC_Conn;

public class ResortDAO_Impl implements ResortDAO {

	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;

	public List<Resort> queryAllResorts() {

		List<Resort> resort_list = null;

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "select * from resorts natural join cities natural join sun_rating";
			stmt = conn.prepareStatement(sql);
			rs = stmt.executeQuery();
			while (rs.next()) {
				if (resort_list == null)
					resort_list = new ArrayList<Resort>();

				Resort resort = new Resort();

				resort.setResort_id(rs.getString("resort_id"));
				resort.setPhone_number(rs.getString("phone_number"));
				resort.setCity(rs.getString("city"));
				resort.setCountry(rs.getString("country"));
				resort.setCity_id(rs.getString("city_id"));
				resort.setResort_nm(rs.getString("resort_nm"));
				resort.setRating(rs.getString("rating"));
				resort.setLuxury_level(rs.getString("luxury_level"));
				resort.setAddress(rs.getString("address"));

				resort_list.add(resort);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}
		return resort_list;

	}

	public Resort queryResortById(String resort_id) {

		Resort resort = null;

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "select * from resorts natural join cities natural join sun_rating where resort_id=?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, resort_id);
			rs = stmt.executeQuery();
			while (rs.next()) {
				resort = new Resort();

				resort.setResort_id(rs.getString("resort_id"));
				resort.setPhone_number(rs.getString("phone_number"));
				resort.setCity(rs.getString("city"));
				resort.setCountry(rs.getString("country"));
				resort.setCity_id(rs.getString("city_id"));
				resort.setResort_nm(rs.getString("resort_nm"));
				resort.setRating(rs.getString("rating"));
				resort.setLuxury_level(rs.getString("luxury_level"));
				resort.setAddress(rs.getString("address"));

			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}
		return resort;

	}

	public List<Resort> queryResortByCondition(Resort resort) {

		List<Resort> resort_list = null;
		int count = 0;

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "select * from resorts natural join cities natural join sun_rating where ";

			if (resort.getResort_nm() != null && !"".equals(resort.getResort_nm())) {
				sql += " resort_nm='" + resort.getResort_nm() + "'" + " and ";
				count++;
			}

			if (resort.getPhone_number() != null && !"".equals(resort.getPhone_number())) {
				sql += " phone_number='" + resort.getPhone_number() + "'" + " and ";
				count++;
			}

			if (resort.getCity() != null && !"".equals(resort.getCity())) {
				sql += " city='" + resort.getCity() + "'" + " and ";
				count++;
			}

			if (resort.getCountry() != null && !"".equals(resort.getCountry())) {
				sql += " country='" + resort.getCountry() + "'" + " and ";
				count++;
			}

			if (resort.getRating() != null && !"".equals(resort.getRating())) {
				sql += " rating='" + resort.getRating() + "'" + " and ";
				count++;
			}

			if (resort.getLuxury_level() != null && !"".equals(resort.getLuxury_level())) {
				sql += " luxury_level='" + resort.getLuxury_level() + "'" + " and ";
				count++;
			}

			if (resort.getAddress() != null && !"".equals(resort.getAddress())) {
				sql += " address='" + resort.getAddress() + "'" + " and ";
				count++;
			}

			if (count == 0)
				return queryAllResorts();

			int last_index = sql.lastIndexOf("and");
			sql = sql.substring(0, last_index);

			stmt = conn.prepareStatement(sql);

			rs = stmt.executeQuery();
			while (rs.next()) {
				if (resort_list == null)
					resort_list = new ArrayList<Resort>();

				resort = new Resort();

				resort.setResort_id(rs.getString("resort_id"));
				resort.setPhone_number(rs.getString("phone_number"));
				resort.setCity(rs.getString("city"));
				resort.setCountry(rs.getString("country"));
				resort.setCity_id(rs.getString("city_id"));
				resort.setResort_nm(rs.getString("resort_nm"));
				resort.setRating(rs.getString("rating"));
				resort.setLuxury_level(rs.getString("luxury_level"));
				resort.setAddress(rs.getString("address"));

				resort_list.add(resort);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}
		return resort_list;

	}

	public void addResort(Resort resort) {

		try {

			conn = JDBC_Conn.getConnection();
			String sql = "insert into resorts values(?,?,?,?,?,?)";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, resort.getResort_id());
			stmt.setString(2, resort.getResort_nm());
			stmt.setString(3, resort.getCity_id());
			stmt.setString(4, resort.getPhone_number());
			stmt.setString(5, resort.getAddress());
			stmt.setString(6, resort.getRating());
			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

	}

	public void deleteResort(String resort_id) {

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "delete from resorts where resort_id = ?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, resort_id);
			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

	}

	public void deleteResortSet(String resort_id_set) {

		try {
			conn = JDBC_Conn.getConnection();
			String sql = "delete from resorts where resort_id in ( " + resort_id_set + " )";
			stmt = conn.prepareStatement(sql);
			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

	}

	public void updateResort(Resort resort) {

		try {
			conn = JDBC_Conn.getConnection();

			// update resort
			String sql = "update resorts set city_id=?, phone_number=?, resort_nm=?, rating=?, address=? where resort_id=?";
			stmt = conn.prepareStatement(sql);
			stmt.setString(1, resort.getCity_id());
			stmt.setString(2, resort.getPhone_number());
			stmt.setString(3, resort.getResort_nm());
			stmt.setString(4, resort.getRating());
			stmt.setString(5, resort.getAddress());
			stmt.setString(6, resort.getResort_id());
			stmt.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBC_Conn.releaseConnection(conn, stmt, rs);
		}

	}

}
