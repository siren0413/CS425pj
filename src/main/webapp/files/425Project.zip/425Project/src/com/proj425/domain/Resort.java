package com.proj425.domain;

public class Resort {
	
	private String resort_id;
	private String resort_nm;
	private String city;
	private String country;
	private String city_id;
	private String phone_number;
	private String rating_id;
	private String rating;
	private String address;
	private String luxury_level;
	
	public Resort() {
		super();
	}

	public String getResort_id() {
		return resort_id;
	}

	public void setResort_id(String resort_id) {
		this.resort_id = resort_id;
	}

	public String getResort_nm() {
		return resort_nm;
	}

	public void setResort_nm(String resort_nm) {
		this.resort_nm = resort_nm;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public String getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(String phone_number) {
		this.phone_number = phone_number;
	}

	public String getRating() {
		return rating;
	}

	public void setRating(String rating) {
		this.rating = rating;
	}

	public String getLuxury_level() {
		return luxury_level;
	}

	public void setLuxury_level(String luxury_level) {
		this.luxury_level = luxury_level;
	}

	public String getCity_id() {
		return city_id;
	}

	public void setCity_id(String city_id) {
		this.city_id = city_id;
	}

	public String getRating_id() {
		return rating_id;
	}

	public void setRating_id(String rating_id) {
		this.rating_id = rating_id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
	
	
	
	
	
	
}
