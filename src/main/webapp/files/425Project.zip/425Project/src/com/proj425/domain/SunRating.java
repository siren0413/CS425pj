package com.proj425.domain;

public class SunRating {
	private String rating;
	private String luxury_level;
	
	

	public SunRating() {
		super();
	}



	public String getRating() {
		return rating;
	}



	public void setRating(String rating) {
		this.rating = rating;
	}



	public String getLuxury_level() {
		return luxury_level;
	}



	public void setLuxury_level(String luxury_level) {
		this.luxury_level = luxury_level;
	}
	
	
	
	
}