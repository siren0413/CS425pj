package com.proj425.service;

import java.util.List;

import com.proj425.domain.Agent;

public interface AgentService {

    List<Agent> findAllAgents();
    
    Agent findAgentById(String id);
    
    List<Agent> findAgentByCondition(Agent agent);
    
    void addAgent(Agent agent);
    
    void deleteAgent(String agent_id);
    
    void deleteAgentSet(String agent_id_set);

    void updateAgent(Agent agent);

}
