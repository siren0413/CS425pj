package com.proj425.service;

import java.util.List;

import com.proj425.domain.Booking;

public interface BookingService {
	
	 List<Booking> findAllBookings();
	    
	    Booking findBookingById(String id);
	    
	    List<Booking> findBookingByCondition(Booking booking);
	    
	    void addBooking(Booking booking);
	    
	    void deleteBooking(String booking_id);
	    
	    void deleteBookingSet(String booking_id_set);
	    
	    void updateBooking(Booking booking);
	
}
