package com.proj425.service.impl;

import java.util.List;

import com.proj425.dao.BookingDAO;
import com.proj425.dao.impl.BookingDAO_Impl;
import com.proj425.domain.Booking;
import com.proj425.domain.City;
import com.proj425.domain.Client;
import com.proj425.service.BookingService;
import com.proj425.service.ClientService;
import com.proj425.utils.CommUtils;

public class BookingServiceImpl implements BookingService {

	private BookingDAO dao = new BookingDAO_Impl();

	public List<Booking> findAllBookings() {
		return dao.queryAllBookings();
	}

	public Booking findBookingById(String id) {
		return dao.queryBookingById(id);
	}

	public List<Booking> findBookingByCondition(Booking booking) {

		return dao.queryBookingByCondition(booking);
	}

	public void addBooking(Booking booking) {

		booking.setBooking_id(CommUtils.getId()); // set ID.

		dao.addBooking(booking);
	}

	public void deleteBooking(String booking_id) {
		dao.deleteBooking(booking_id);

	}

	public void deleteBookingSet(String booking_id_set) {
		dao.deleteBookingSet(booking_id_set);
	}

	public void updateBooking(Booking booking) {
		dao.updateBooking(booking);

	}

}
