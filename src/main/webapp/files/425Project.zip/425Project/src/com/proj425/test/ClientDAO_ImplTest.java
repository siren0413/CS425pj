package com.proj425.test;

import com.proj425.dao.ClientDAO;
import com.proj425.dao.impl.ClientDAO_Impl;
import com.proj425.domain.Client;
import org.junit.Test;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ClientDAO_ImplTest {

    private ClientDAO dao = new ClientDAO_Impl();

    @Test
    public void testQueryAllClients() {

        List<Client> list = dao.queryAllClients();

        for (Client client : list) {
            System.out.println(client.getClient_id());
            System.out.println(client.getPhone_number());
            System.out.println(client.getEmail());
            System.out.println(client.getFirst_nm());
            System.out.println(client.getLast_nm());
            System.out.println(client.getDob().toString());
            System.out.println(client.getZip());
            System.out.println(client.getGender());
            System.out.println("***********************************");
        }


    }

    @Test
    public void testQueryClientById() {

        String client_id = "100";
        Client client = dao.queryClientById(client_id);

        System.out.println(client.getClient_id());
        System.out.println(client.getPhone_number());
        System.out.println(client.getEmail());
        System.out.println(client.getFirst_nm());
        System.out.println(client.getLast_nm());
        System.out.println(client.getDob().toString());
        System.out.println(client.getZip());
        System.out.println(client.getGender());
        System.out.println("***********************************");

    }
    
    @Test
    public void testQueryClientByConditions() {
    
    }
    

    @Test
    public void testAddClient() {
        Client client = new Client();

        client.setClient_id("100");
        client.setPhone_number("123456789");
        client.setLast_nm("Mao");
        client.setFirst_nm("vincent");
        client.setDob(new Date());
        client.setZip("60661");
        client.setGender("M");
        client.setEmail("siren0413@gmail.com");

        dao.addClient(client);

    }

    @Test
    public void testDeleteClient() {

        String client_id = "100";

        dao.deleteClient(client_id);


    }

    @Test
    public void testUpdateClient() {

        Client client = new Client();

        client.setClient_id("100");
        client.setPhone_number("3127315699");
        client.setLast_nm("Wang");
        client.setFirst_nm("Helen");
        client.setDob(new Date());
        client.setZip("60661");
        client.setGender("F");
        client.setEmail("helen789@gmail.com");

        dao.updateClient(client);
    }

}
