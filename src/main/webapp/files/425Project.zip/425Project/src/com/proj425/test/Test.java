package com.proj425.test;

import com.proj425.dao.ClientDAO;
import com.proj425.dao.impl.ClientDAO_Impl;
import com.proj425.domain.Client;

import java.util.List;

public class Test {
    public static void main(String[] args) {
        ClientDAO dao = new ClientDAO_Impl();
        List<Client> list =  dao.queryAllClients();

        for(Client c : list) {
            System.out.println(c.getClient_id());
            System.out.println(c.getEmail());
            System.out.println(c.getFirst_nm());
            System.out.println(c.getLast_nm());
            System.out.println(c.getPhone_number());
            System.out.println(c.getDob());
            System.out.println(c.getZip());
            System.out.println(c.getGender());
            System.out.println("*********************************************************");
        }
        
    }
}
