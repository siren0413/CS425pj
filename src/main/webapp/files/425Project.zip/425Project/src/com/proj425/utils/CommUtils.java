package com.proj425.utils;

import java.util.UUID;

/**
 * Created with IntelliJ IDEA.
 * User: Siren
 * Date: 4/16/13
 * Time: 6:28 PM
 * To change this template use File | Settings | File Templates.
 */
public class CommUtils {

    public static String getId(){
        return UUID.randomUUID().toString();
    }


}
