package com.proj425.web.UI;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.Booking;
import com.proj425.service.BookingService;
import com.proj425.service.impl.BookingServiceImpl;

public class BookingUpdateUI extends HttpServlet {
	
	private BookingService booking_service = new BookingServiceImpl();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
		String booking_id = request.getParameter("booking_id");
		
		Booking booking = booking_service.findBookingById(booking_id);
		
		
		request.setAttribute("booking",booking);
		
		request.getRequestDispatcher("/WEB-INF/pages/booking/booking_update.jsp").forward(request, response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
