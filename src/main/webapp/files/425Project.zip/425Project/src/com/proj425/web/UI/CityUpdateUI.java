package com.proj425.web.UI;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.City;
import com.proj425.service.CityService;
import com.proj425.service.impl.CityServiceImpl;

public class CityUpdateUI extends HttpServlet {

	
	private CityService city_service = new CityServiceImpl();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		

		String city_id = request.getParameter("city_id");
	
		City city = city_service.findCityById(city_id);
		
		request.setAttribute("city",city);
		
		request.getRequestDispatcher("/WEB-INF/pages/city/city_update.jsp").forward(request, response);
		
		
		
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
