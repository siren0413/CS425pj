package com.proj425.web.UI;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.dao.ClientDAO;
import com.proj425.dao.impl.ClientDAO_Impl;
import com.proj425.domain.Client;
import com.proj425.service.ClientService;
import com.proj425.service.impl.ClientServiceImpl;

public class ClientUpdateUI extends HttpServlet {
	
	private ClientService client_service = new ClientServiceImpl();

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String client_id = request.getParameter("client_id");
	
		Client client = client_service.findClientById(client_id);
		
		request.setAttribute("client",client);
		
		request.getRequestDispatcher("/WEB-INF/pages/client/client_update.jsp").forward(request, response);
	
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
