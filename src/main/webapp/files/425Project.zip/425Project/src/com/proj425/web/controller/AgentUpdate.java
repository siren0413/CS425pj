package com.proj425.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.Agent;
import com.proj425.domain.PageStatus;
import com.proj425.service.AgentService;
import com.proj425.service.impl.AgentServiceImpl;

public class AgentUpdate extends HttpServlet {

	private AgentService agent_service = new AgentServiceImpl();

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Map<String, String[]> args = request.getParameterMap();

		Agent agent = new Agent();

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date dob = null;

		if (!args.get("dob")[0].equals("")) {
			try {
				dob = sdf.parse(args.get("dob")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}

		agent.setDob(dob);

		agent.setAgent_id(args.get("agent_id")[0]);
		agent.setFirst_nm(args.get("first_nm")[0]);
		agent.setLast_nm(args.get("last_nm")[0]);
		agent.setGender(args.get("gender")[0]);
		agent.setPhone_number(args.get("phone_number")[0]);
		agent.setZip(args.get("zip")[0]);
		agent.setEmail(args.get("email")[0]);
		agent.setPosition(args.get("position")[0]);
		
		
		
		if(checkExist(agent)) {
			PageStatus status = new PageStatus("Agent","Error: \n Duplicate Agents!", "/425pj/AgentManage");
			request.setAttribute("page_status", status);
			request.getRequestDispatcher("/WEB-INF/pages/status/update_fail.jsp").forward(request, response);
			return;
		}

		agent_service.updateAgent(agent);

		request.setAttribute("page_status", new PageStatus("Agent", "Update Success!", "/425pj/AgentManage"));
		request.getRequestDispatcher("/WEB-INF/pages/status/update_success.jsp").forward(request, response);

	}
	
	

	private boolean checkExist(Agent agent) {

		List<Agent> agent_list = agent_service.findAgentByCondition(agent);
		if (agent_list == null || agent_list.size() == 0) {
			return false;
		}else if( agent_list.get(0).getAgent_id().equals(agent.getAgent_id())){
			return false;
		}
		
		return true;
			
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
