package com.proj425.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.Agent;
import com.proj425.domain.Booking;
import com.proj425.domain.Client;
import com.proj425.domain.PageStatus;
import com.proj425.domain.Resort;
import com.proj425.service.AgentService;
import com.proj425.service.BookingService;
import com.proj425.service.ClientService;
import com.proj425.service.ResortService;
import com.proj425.service.impl.AgentServiceImpl;
import com.proj425.service.impl.BookingServiceImpl;
import com.proj425.service.impl.ClientServiceImpl;
import com.proj425.service.impl.ResortServiceImpl;

public class BookingAdd extends HttpServlet {

	ClientService client_service = new ClientServiceImpl();
	AgentService agent_service = new AgentServiceImpl();
	ResortService resort_service = new ResortServiceImpl();
	BookingService booking_service = new BookingServiceImpl();

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Map<String, String[]> args = request.getParameterMap();

		Booking booking = new Booking();

		// book date
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date date = null;

		if (!args.get("book_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("book_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}

		booking.setBook_date(date);

		// arrive date
		if (!args.get("arrive_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("arrive_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		booking.setArrive_date(date);

		// departure date
		if (!args.get("departure_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("departure_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		booking.setDeparture_date(date);

		// room type
		booking.setRoom_type(args.get("room_type")[0]);
		booking.setActivity(args.get("activity")[0]);

		// client
		Client client = new Client();
		client.setFirst_nm(args.get("c_first_nm")[0]);
		client.setLast_nm(args.get("c_last_nm")[0]);
		client.setPhone_number(args.get("c_phone_number")[0]);
		List<Client> client_list = client_service.findClientByCondition(client);
		if (client_list == null || client_list.size() == 0) {
			request.getRequestDispatcher("/WEB-INF/pages/booking/no_client.jsp").forward(request, response);
			return;
		} else {
			String client_id = client_list.get(0).getClient_id();
			client.setClient_id(client_id);
			booking.setClient(client);
		}

		// agent
		Agent agent = new Agent();
		agent.setFirst_nm(args.get("a_first_nm")[0]);
		agent.setLast_nm(args.get("a_last_nm")[0]);
		agent.setPhone_number(args.get("a_phone_number")[0]);
		List<Agent> agent_list = agent_service.findAgentByCondition(agent);
		if (agent_list == null || agent_list.size() == 0) {
			request.getRequestDispatcher("/WEB-INF/pages/booking/no_agent.jsp").forward(request, response);
			return;
		} else {
			String agent_id = agent_list.get(0).getAgent_id();
			agent.setAgent_id(agent_id);
			booking.setAgent(agent);
		}

		// resort
		Resort resort = new Resort();
		resort.setResort_nm(args.get("resort_nm")[0]);
		resort.setPhone_number(args.get("resort_phone_number")[0]);
		List<Resort> resort_list = resort_service.findResortByCondition(resort);
		if (resort_list == null || resort_list.size() == 0) {
			request.getRequestDispatcher("/WEB-INF/pages/booking/no_resort.jsp").forward(request, response);
			return;
		} else {
			String resort_id = resort_list.get(0).getResort_id();
			resort.setResort_id(resort_id);
			booking.setResort(resort);
		}

		booking_service.addBooking(booking);

		request.setAttribute("page_status", new PageStatus("Booking", "Add Success!", "/425pj/BookingManage"));
		request.getRequestDispatcher("/WEB-INF/pages/status/update_success.jsp").forward(request, response);

	}
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
