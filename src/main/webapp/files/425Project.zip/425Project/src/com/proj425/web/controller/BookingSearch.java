package com.proj425.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.Agent;
import com.proj425.domain.Booking;
import com.proj425.domain.Client;
import com.proj425.domain.Resort;
import com.proj425.service.BookingService;
import com.proj425.service.impl.BookingServiceImpl;

public class BookingSearch extends HttpServlet {

	private BookingService booking_service = new BookingServiceImpl();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Map<String, String[]> args = request.getParameterMap();

		Booking booking = new Booking();

		booking.setBooking_id("");
		
		
		// set client
		Client client = new Client();
		client.setClient_id("");
		client.setFirst_nm(args.get("c_first_nm")[0]);
		client.setLast_nm(args.get("c_last_nm")[0]);
		booking.setClient(client);
		
		// set agent
		Agent agent = new Agent();
		agent.setAgent_id("");
		agent.setFirst_nm(args.get("a_first_nm")[0]);
		agent.setLast_nm(args.get("a_last_nm")[0]);
		booking.setAgent(agent);
		
		// set resort
		Resort resort = new Resort();
		resort.setResort_id("");
		resort.setResort_nm(args.get("resort_nm")[0]);
		booking.setResort(resort);
		
		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date date = null;
		
		// set booking date
		if (!args.get("book_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("book_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		booking.setBook_date(date);
		
		// set arrive date
		if (!args.get("arrive_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("arrive_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		booking.setArrive_date(date);
		
		// set departure date
		if (!args.get("departure_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("departure_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		booking.setDeparture_date(date);
		
		// set others
		booking.setRoom_type(args.get("room_type")[0]);
		booking.setActivity(args.get("activity")[0]);
	
		List<Booking> booking_list = booking_service.findBookingByCondition(booking);

		request.setAttribute("booking_list", booking_list);

		request.getRequestDispatcher("/WEB-INF/pages/booking/booking_list.jsp").forward(request, response);
		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
