package com.proj425.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.Agent;
import com.proj425.domain.Booking;
import com.proj425.domain.Client;
import com.proj425.domain.PageStatus;
import com.proj425.domain.Resort;
import com.proj425.service.AgentService;
import com.proj425.service.BookingService;
import com.proj425.service.ClientService;
import com.proj425.service.ResortService;
import com.proj425.service.impl.AgentServiceImpl;
import com.proj425.service.impl.BookingServiceImpl;
import com.proj425.service.impl.ClientServiceImpl;
import com.proj425.service.impl.ResortServiceImpl;

public class BookingUpdate extends HttpServlet {
	
	

	ClientService client_service = new ClientServiceImpl();
	AgentService agent_service = new AgentServiceImpl();
	ResortService resort_service = new ResortServiceImpl();
	BookingService booking_service = new BookingServiceImpl();


	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Map<String, String[]> args = request.getParameterMap();

		Booking booking = new Booking();

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date date = null;
		
		//client
		Client client = new Client();
		if (!args.get("c_dob")[0].equals("")) {
			try {
				date = sdf.parse(args.get("c_dob")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		client.setDob(date);
		client.setFirst_nm(args.get("c_first_nm")[0]);
		client.setLast_nm(args.get("c_last_nm")[0]);
		client.setGender(args.get("c_gender")[0]);
		client.setPhone_number(args.get("c_phone_number")[0]);
		client.setZip(args.get("c_zip")[0]);
		client.setEmail(args.get("c_email")[0]);
		
		String id = checkExist(client);
		if(id!=null) {
			client.setClient_id(id);
		}else {
			request.getRequestDispatcher("/WEB-INF/pages/booking/no_client.jsp").forward(request, response);
			return;
		}
		booking.setClient(client);
		
		// agent
		Agent agent = new Agent();
		if (!args.get("a_dob")[0].equals("")) {
			try {
				date = sdf.parse(args.get("a_dob")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		agent.setDob(date);
		agent.setFirst_nm(args.get("a_first_nm")[0]);
		agent.setLast_nm(args.get("a_last_nm")[0]);
		agent.setGender(args.get("a_gender")[0]);
		agent.setPhone_number(args.get("a_phone_number")[0]);
		agent.setZip(args.get("a_zip")[0]);
		agent.setEmail(args.get("a_email")[0]);
		
		id = checkExist(agent);
		if(id!=null) {
			agent.setAgent_id(id);
		}else {
			request.getRequestDispatcher("/WEB-INF/pages/booking/no_agent.jsp").forward(request, response);
			return;
		}
		booking.setAgent(agent);
		
		
		// resort
		Resort resort = new Resort();
		
		resort.setResort_nm(args.get("resort_nm")[0]);
		resort.setPhone_number(args.get("resort_phone_number")[0]);
		resort.setCity_id(args.get("city_id")[0]);
		resort.setAddress(args.get("address")[0]);
		resort.setRating(args.get("rating")[0]);
		
		id = checkExist(resort);
		if(id!=null) {
			resort.setResort_id(id);
		}else{
			request.getRequestDispatcher("/WEB-INF/pages/booking/no_resort.jsp").forward(request, response);
			return;
		}
		booking.setResort(resort);
		

		// book date
		if (!args.get("book_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("book_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		booking.setBook_date(date);
		
		// arrive date
		if (!args.get("arrive_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("arrive_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		booking.setArrive_date(date);
		
		// departure date
		if (!args.get("departure_date")[0].equals("")) {
			try {
				date = sdf.parse(args.get("departure_date")[0]);
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		booking.setDeparture_date(date);
		

		booking.setActivity(args.get("activity")[0]);
		booking.setRoom_type(args.get("room_type")[0]);
		booking.setBooking_id(args.get("booking_id")[0]);
		
		if(checkExist(booking)) {
			PageStatus status = new PageStatus("Booking","Error: \n Duplicate Bookings!", "/425pj/BookingManage");
			request.setAttribute("page_status", status);
			request.getRequestDispatcher("/WEB-INF/pages/status/update_fail.jsp").forward(request, response);
			return;
		}
		
		
		booking_service.updateBooking(booking);
		
		
		PageStatus status = new PageStatus("Booking","Update Success!", "/425pj/BookingManage");
		request.setAttribute("page_status", status);
		request.getRequestDispatcher("/WEB-INF/pages/status/update_success.jsp").forward(request, response);
	}
	
	private String checkExist(Client client) {

		List<Client> client_list = client_service.findClientByCondition(client);
		if (client_list == null || client_list.size() == 0) {
			return null;
		}else if( client_list.get(0).getClient_id().equals(client.getClient_id())){
			return null;
		}
		
		return client_list.get(0).getClient_id();

	}
	
	private String checkExist(Agent agent) {

		List<Agent> agent_list = agent_service.findAgentByCondition(agent);
		if (agent_list == null || agent_list.size() == 0) {
			return null;
		}else if( agent_list.get(0).getAgent_id().equals(agent.getAgent_id())){
			return null;
		}
		
		return agent_list.get(0).getAgent_id();

	}
	
	private String checkExist(Resort resort) {

		List<Resort> resort_list = resort_service.findResortByCondition(resort);
		if (resort_list == null || resort_list.size() == 0) {
			return null;
		}else if( resort_list.get(0).getResort_id().equals(resort.getResort_id())){
			return null;
		}
		
		return resort_list.get(0).getResort_id();

	}
	
	private boolean checkExist(Booking booking) {

		List<Booking> booking_list = booking_service.findBookingByCondition(booking);
		if (booking_list == null || booking_list.size() == 0) {
			return false;
		}else if( booking_list.get(0).getBooking_id().equals(booking.getBooking_id())){
			return false;
		}
		
		return true;
	}
	

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
