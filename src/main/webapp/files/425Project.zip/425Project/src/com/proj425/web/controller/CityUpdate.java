package com.proj425.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.City;
import com.proj425.domain.PageStatus;
import com.proj425.service.CityService;
import com.proj425.service.impl.CityServiceImpl;

public class CityUpdate extends HttpServlet {

	
	private CityService city_service = new CityServiceImpl();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {


		Map<String, String[]> args = request.getParameterMap();

		City city = new City();

		city.setCity_id(args.get("city_id")[0]);
		city.setCity(args.get("city")[0]);
		city.setCountry(args.get("country")[0]);


		if(checkExist(city)) {
			PageStatus status = new PageStatus("City","Error: \n Duplicate Citys!", "/425pj/CityManage");
			request.setAttribute("page_status", status);
			request.getRequestDispatcher("/WEB-INF/pages/status/update_fail.jsp").forward(request, response);
			return;
		}
		

		city_service.updateCity(city);

		request.setAttribute("page_status", new PageStatus("City", "Update Success!", "/425pj/CityManage"));
		request.getRequestDispatcher("/WEB-INF/pages/status/update_success.jsp").forward(request, response);
	}
	
	
	private boolean checkExist(City city) {

		List<City> city_list = city_service.findCityByCondition(city);
		if (city_list == null || city_list.size() == 0) {
			return false;
		}else if( city_list.get(0).getCity_id().equals(city.getCity_id())){
			return false;
		}
		
		return true;
			
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
