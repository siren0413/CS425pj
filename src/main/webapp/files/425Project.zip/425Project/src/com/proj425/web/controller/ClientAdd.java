package com.proj425.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.Client;
import com.proj425.domain.PageStatus;
import com.proj425.service.ClientService;
import com.proj425.service.impl.ClientServiceImpl;

public class ClientAdd extends HttpServlet {

	
	private ClientService client_service = new ClientServiceImpl();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		

		Map<String, String[]> args = request.getParameterMap();

		Client client = new Client();
		

		SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
		Date dob = null;
				
		if(!args.get("dob")[0].equals("")) {
		try {
			dob = sdf.parse(args.get("dob")[0]);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		}
		
		
		client.setDob(dob);
		
		
		client.setFirst_nm(args.get("first_nm")[0]);
		client.setLast_nm(args.get("last_nm")[0]);
		client.setGender(args.get("gender")[0]);
		client.setPhone_number(args.get("phone_number")[0]);
		client.setZip(args.get("zip")[0]);
		client.setEmail(args.get("email")[0]);
		
		if(checkExist(client)) {
			PageStatus status = new PageStatus("Client","Error: \n Duplicate Clients!", "/425pj/ClientManage");
			request.setAttribute("page_status", status);
			request.getRequestDispatcher("/WEB-INF/pages/status/update_fail.jsp").forward(request, response);
			return;
		}
		
		client_service.addClient(client);

		request.setAttribute("page_status", new PageStatus("Client", "Add Success!", "/425pj/ClientManage"));
		request.getRequestDispatcher("/WEB-INF/pages/status/update_success.jsp").forward(request, response);
		
		
	}
	
	private boolean checkExist(Client client) {

		List<Client> client_list = client_service.findClientByCondition(client);
		if (client_list == null || client_list.size() == 0) {
			return false;
		}else if( client_list.get(0).getClient_id().equals(client.getClient_id())){
			return false;
		}
		
		return true;
			
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
