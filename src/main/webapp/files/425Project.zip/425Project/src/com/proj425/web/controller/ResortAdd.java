package com.proj425.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.PageStatus;
import com.proj425.domain.Resort;
import com.proj425.service.ResortService;
import com.proj425.service.impl.ResortServiceImpl;

public class ResortAdd extends HttpServlet {

	private ResortService resort_service = new ResortServiceImpl();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		Map<String, String[]> args = request.getParameterMap();

		Resort resort = new Resort();
		

		resort.setResort_nm(args.get("resort_nm")[0]);
		resort.setCity(args.get("city")[0]);
		resort.setCountry(args.get("country")[0]);
		resort.setPhone_number(args.get("phone_number")[0]);
		resort.setRating(args.get("rating")[0]);
		resort.setAddress(args.get("address")[0]);
		
		
		if(checkExist(resort)) {
			PageStatus status = new PageStatus("Resort","Error: \n Duplicate Resorts!", "/425pj/ResortManage");
			request.setAttribute("page_status", status);
			request.getRequestDispatcher("/WEB-INF/pages/status/update_fail.jsp").forward(request, response);
			return;
		}
		
		resort_service.addResort(resort);
		
		request.setAttribute("page_status", new PageStatus("Resort", "Add Success!", "/425pj/ResortManage"));
		request.getRequestDispatcher("/WEB-INF/pages/status/update_success.jsp").forward(request, response);
		
		
	}
	
	
	private boolean checkExist(Resort resort) {

		List<Resort> resort_list = resort_service.findResortByCondition(resort);
		if (resort_list == null || resort_list.size() == 0) {
			return false;
		}else if( resort_list.get(0).getResort_id().equals(resort.getResort_id())){
			return false;
		}
		
		return true;
			
	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
		
	}

}
