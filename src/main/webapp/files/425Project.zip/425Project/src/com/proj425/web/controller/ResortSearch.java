package com.proj425.web.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.proj425.domain.Resort;
import com.proj425.service.ResortService;
import com.proj425.service.impl.ResortServiceImpl;

public class ResortSearch extends HttpServlet {

	private ResortService resort_service = new ResortServiceImpl();
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Map<String, String[]> args = request.getParameterMap();

		Resort resort = new Resort();
		
		resort.setResort_id("");
		resort.setResort_nm(args.get("resort_nm")[0]);
		resort.setCity(args.get("city")[0]);
		resort.setCountry(args.get("country")[0]);
		resort.setPhone_number(args.get("phone_number")[0]);
		resort.setRating(args.get("rating")[0]);
		resort.setLuxury_level(args.get("luxury_level")[0]);
		resort.setAddress(args.get("address")[0]);
		
		List<Resort> resort_list = resort_service.findResortByCondition(resort);
		
		request.setAttribute("resort_list", resort_list);

		request.getRequestDispatcher("/WEB-INF/pages/resort/resort_list.jsp").forward(request, response);

		
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		doGet(request, response);
	}

}
